from pathlib import Path

from core.spec_parser import create_design_spec
from core.optimizer import optimize_length
from core.report_generator import generate_report
from layout.gds_generator import generate_gds, generate_layout_preview


OUTPUT_DIR = Path("outputs")
OUTPUT_DIR.mkdir(exist_ok=True)


def main():
    """
    主函数：按顺序执行整个 V0 demo 流程。
    """
    # 第一步：创建设计参数
    spec = create_design_spec(output_dir=OUTPUT_DIR)

    # 第二步：进行 MMI 长度扫描和参数优化
    result = optimize_length(spec=spec, output_dir=OUTPUT_DIR)

    # 第三步：根据优化结果生成 GDS 版图
    gds_path = generate_gds(spec=spec, result=result, output_dir=OUTPUT_DIR)

    # 第四步：生成简化版图预览图
    layout_preview_path = generate_layout_preview(
        spec=spec,
        result=result,
        output_dir=OUTPUT_DIR,
    )

    # 第五步：生成自动设计报告
    report_path = generate_report(
        spec=spec,
        result=result,
        gds_path=gds_path,
        output_dir=OUTPUT_DIR,
    )

    # 在终端输出关键结果
    print("=" * 60)
    print("AI-Assisted 1x2 MMI Splitter Design Demo Finished")
    print("=" * 60)
    print(f"Initial MMI length: {result['initial_length_um']:.3f} um")
    print(f"Best MMI length:    {result['best_length_um']:.3f} um")
    print(f"Output port 1:      {result['p_out1']:.4f}")
    print(f"Output port 2:      {result['p_out2']:.4f}")
    print(f"Insertion loss:     {result['insertion_loss_db']:.3f} dB")
    print(f"Imbalance:          {result['imbalance_db']:.3f} dB")
    print("-" * 60)
    print(f"GDS file:           {gds_path}")
    print(f"Layout preview:     {layout_preview_path}")
    print(f"Report:             {report_path}")
    print(f"Plot:               {OUTPUT_DIR / 'length_sweep.png'}")
    print("=" * 60)


if __name__ == "__main__":
    main()
