import json
import re
from pathlib import Path


def save_design_spec(spec: dict, output_dir: Path):
    """
    保存设计参数到 design_spec.json。

    这个函数既可以给 run_demo.py 使用，
    也可以给 Streamlit 网页界面使用。
    """
    spec_path = output_dir / "design_spec.json"

    with open(spec_path, "w", encoding="utf-8") as f:
        json.dump(spec, f, indent=4, ensure_ascii=False)

    return spec_path


def parse_design_text(user_text: str):
    """将自然语言需求解析成 V0 设计参数。

    当前采用可复现的规则解析，后续可以在保持返回结构不变的情况下
    替换为大语言模型或其他 AI 解析服务。
    """
    spec = {
        "component": "1x2_mmi_splitter",
        "platform": "SOI",
        "wavelength_um": 1.55,
        "neff": 2.8,
        "waveguide_width_um": 0.5,
        "mmi_width_um": 2.5,
        "target_split_ratio": [0.5, 0.5],
        "length_scan_range_um": [3.0, 20.0],
        "num_scan_points": 200,
    }

    text = (user_text or "").lower().replace("μ", "u").replace("µ", "u")

    wavelength_nm = re.search(r"(\d+(?:\.\d+)?)\s*nm\b", text)
    wavelength_um = re.search(r"(\d+(?:\.\d+)?)\s*(?:um|微米)", text)
    if wavelength_nm:
        spec["wavelength_um"] = float(wavelength_nm.group(1)) / 1000
    elif wavelength_um:
        spec["wavelength_um"] = float(wavelength_um.group(1))

    if "sin" in text or "氮化硅" in text:
        spec["platform"] = "SiN"
        spec["neff"] = 2.0
    elif "soi" in text or "绝缘体上硅" in text:
        spec["platform"] = "SOI"

    neff_match = re.search(r"n[_\s-]*eff\s*(?:=|为|是)?\s*(\d+(?:\.\d+)?)", text)
    if neff_match:
        spec["neff"] = float(neff_match.group(1))

    ratio_match = re.search(
        r"(\d+(?:\.\d+)?)\s*[:：/]\s*(\d+(?:\.\d+)?)",
        text,
    )
    if ratio_match:
        first = float(ratio_match.group(1))
        second = float(ratio_match.group(2))
        total = first + second
        if total > 0:
            spec["target_split_ratio"] = [first / total, second / total]

    return spec


def create_design_spec(output_dir: Path):
    """
    创建设计参数。

    当前 V0 版本中，设计参数是手动写死的。
    后续可以将这一部分替换为 AI 需求解析模块，
    让 AI 根据自然语言生成结构化设计参数。
    """
    spec = {
        "component": "1x2_mmi_splitter",
        "platform": "SOI",
        "wavelength_um": 1.55,
        "neff": 2.8,
        "waveguide_width_um": 0.5,
        "mmi_width_um": 2.5,
        "target_split_ratio": [0.5, 0.5],
        "length_scan_range_um": [3.0, 20.0],
        "num_scan_points": 200,
    }

    save_design_spec(spec=spec, output_dir=output_dir)

    return spec
