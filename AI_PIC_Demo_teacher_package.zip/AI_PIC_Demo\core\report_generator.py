from pathlib import Path


def generate_report(spec, result, gds_path, output_dir: Path):
    """
    自动生成中文 Markdown 格式设计报告。

    报告内容包括：
    1. Demo 目标；
    2. 设计目标；
    3. 输入参数；
    4. MMI 原理；
    5. 参数扫描与优化结果；
    6. 扫描图和版图预览图；
    7. 自动生成文件；
    8. 当前局限性；
    9. 后续升级方向。
    """
    report = f"""# 基于 AI 的 1×2 MMI 光功率分束器自动设计报告

## 1. Demo 目标

本 demo 旨在搭建一个最小化的 AI-assisted 光子芯片设计流程原型。

当前版本以 **1×2 MMI 光功率分束器** 为示例，完成以下自动化流程：

自然语言设计需求  
→ 结构化设计参数  
→ 初始物理建模  
→ MMI 长度参数扫描  
→ 参数优化  
→ GDS 版图生成  
→ 版图预览图生成  
→ 自动设计报告输出

需要注意的是，当前版本的仿真部分使用的是轻量级替代模型，并不是真实的 FDTD、FEM 或 EME 电磁场仿真。该版本主要用于验证自动化设计框架是否能够跑通。

---

## 2. 设计目标

- 器件类型：{spec["component"]}
- 光子平台：{spec["platform"]}
- 工作波长：{spec["wavelength_um"]} μm
- 目标分光比：50:50
- 设计目标：使两个输出端口功率尽可能接近，同时保持较低插入损耗和较小分光不均衡。

---

## 3. 输入设计参数

| 参数 | 数值 | 说明 |
|---|---:|---|
| 工作波长 | {spec["wavelength_um"]} μm | 器件的目标工作波长 |
| 有效折射率 neff | {spec["neff"]} | V0 简化模型中使用的有效折射率 |
| 输入/输出波导宽度 | {spec["waveguide_width_um"]} μm | 单模波导宽度 |
| MMI 区域宽度 | {spec["mmi_width_um"]} μm | 多模干涉区域宽度 |
| 长度扫描范围 | {spec["length_scan_range_um"][0]}–{spec["length_scan_range_um"][1]} μm | 用于寻找最佳 MMI 长度 |
| 扫描点数 | {spec["num_scan_points"]} | 参数扫描的采样点数量 |

---

## 4. 初始物理建模

MMI 分束器的基本原理是 **多模干涉自成像效应**。

当输入光进入较宽的 MMI 区域后，会激发多个横向传播模式。不同模式具有不同的传播常数，在传播过程中会产生相位差。当传播到特定长度位置时，多个模式会重新组合，形成一个或多个光场自成像，从而实现光功率分束。

当前 V0 demo 使用简化自成像模型估算初始 MMI 长度：

- 初始估算 MMI 长度：{result["initial_length_um"]:.3f} μm

该长度只作为参数扫描的初始参考，并不代表最终精确设计结果。

---

## 5. 参数扫描与优化结果

系统在设定的 MMI 长度范围内进行参数扫描，并根据输出功率、插入损耗和分光不均衡计算评分，选择当前模型下最优的 MMI 长度。

最终优化结果如下：

| 指标 | 结果 |
|---|---:|
| 最佳 MMI 长度 | {result["best_length_um"]:.3f} μm |
| Output port 1 归一化功率 | {result["p_out1"]:.4f} |
| Output port 2 归一化功率 | {result["p_out2"]:.4f} |
| 插入损耗 | {result["insertion_loss_db"]:.3f} dB |
| 分光不均衡 | {result["imbalance_db"]:.3f} dB |

从当前结果看，两个输出端口的功率接近 0.5，说明该设计在简化模型下实现了接近 50:50 的分光效果。

---

## 6. MMI 长度扫描图

下图展示了不同 MMI 长度下两个输出端口的归一化功率变化。

![MMI 长度扫描结果](length_sweep.png)

---

## 7. 版图预览图

下图展示了当前设计参数对应的 1×2 MMI 分束器简化版图结构。

![1×2 MMI 版图预览](layout_preview.png)

需要注意的是，该图是根据设计参数生成的结构示意图，不是 GDS 文件的精确截图。真正的版图文件已经通过 gdsfactory 自动生成为 GDS 格式。

---

## 8. 自动生成文件

本次设计流程自动生成了以下文件：

| 文件 | 作用 |
|---|---|
| `outputs/design_spec.json` | 保存结构化设计参数 |
| `outputs/optimization_result.json` | 保存优化结果 |
| `outputs/length_sweep.png` | MMI 长度扫描曲线 |
| `outputs/layout_preview.png` | 1×2 MMI 简化版图预览 |
| `{gds_path}` | 生成的 GDS 版图文件 |
| `outputs/report.md` | 自动生成的设计报告 |

其中，GDS 文件可用于后续版图查看、器件集成或进一步设计验证。

---

## 9. 当前 V0 demo 的局限性

当前版本主要用于验证自动化流程，因此仍有以下局限：

1. **仿真模型较简化**  
   当前使用的是 lightweight surrogate model，并不是真实电磁场仿真。

2. **没有计算真实模场分布**  
   当前版本没有求解 TE/TM 模式、有效折射率分布或场强分布。

3. **没有真实 S 参数提取**  
   插入损耗和分光不均衡来自简化模型，不代表最终制造器件的真实性能。

4. **尚未加入 PDK 设计规则检查**  
   当前 GDS 版图可以生成，但还没有进行 DRC、LVS 或工艺规则验证。

5. **自然语言解析模块仍是规则版**  
   当前解析器使用关键词和正则表达式实现，后续可替换为大模型 API 或 LangGraph workflow。

---

## 10. 后续升级方向

后续可以从以下几个方向继续完善：

1. **接入真实电磁场求解器**  
   将 `core/mmi_model.py` 中的简化模型替换为 Meep、Tidy3D、FEMWELL、COMSOL 或 Ansys Lumerical 的仿真结果。

2. **加入模式求解模块**  
   先求解波导截面的有效折射率 neff、群折射率 ng 和模式场分布，再传递给器件设计模块。

3. **加入 AI 需求解析模块**  
   将当前规则版解析器替换为大模型结构化输出，使用户可以用更自然的语言描述设计目标。

4. **扩展器件库**  
   在 1×2 MMI 的基础上，继续加入 ring resonator、directional coupler、grating coupler、Y-branch 等常见 PIC 器件。

5. **加入 PDK 和版图验证流程**  
   后续可结合 gdsfactory PDK、LayerStack、DRC 规则等内容，使 demo 更接近真实 PIC 设计流程。

6. **形成完整平台界面**  
   当前 Streamlit 页面可以继续扩展为包含需求输入、参数确认、仿真结果、版图预览和报告下载的完整界面。

---

## 11. 阶段性结论

当前 demo 已经初步跑通了一个 AI-assisted 光子芯片设计平台的最小闭环。

虽然当前仿真模型仍然是简化版本，但系统已经完成了从设计需求到结构化参数、从参数扫描到版图生成、从结果分析到报告输出的自动化流程。

该版本可以作为后续接入真实电磁仿真器和 AI 工作流的基础框架。
"""

    report_path = output_dir / "report.md"
    report_path.write_text(report, encoding="utf-8")

    return report_path