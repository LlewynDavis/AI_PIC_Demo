# AI-Assisted 1×2 MMI Splitter Design Demo

这是一个面向教学展示的 AI-assisted 光子芯片设计 V0 原型。项目演示了从自然语言需求到结构化参数、简化物理建模、长度扫描优化、GDS 版图生成、版图预览和自动报告输出的完整流程。

> 注意：当前性能结果来自轻量级替代模型，不是真实的 FDTD、FEM 或 EME 电磁仿真结果，不能直接作为流片依据。

## 解压后直接查看

无需安装软件即可先查看 `outputs` 文件夹中的结果：

- `report.md`：完整中文设计报告（在 VS Code 中按 `Ctrl+Shift+V` 预览）
- `length_sweep.png`：MMI 长度扫描图
- `layout_preview.png`：1×2 MMI 简化版图预览
- `mmi1x2_demo.gds`：gdsfactory 生成的 GDS 版图
- `design_spec.json`：结构化设计参数
- `optimization_result.json`：优化结果
- `ai_pic_demo_results.zip`：单次运行结果包

## 运行环境

- Windows 10/11
- Python 3.11
- 推荐使用 PowerShell 或 VS Code

## 一键启动网页 Demo

双击项目根目录中的 `start_demo.bat`。首次运行会创建 `.venv` 并安装依赖，安装过程需要联网，随后浏览器会打开 Streamlit 页面。

也可以在 PowerShell 中手动运行：

```powershell
python -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
streamlit run app.py
```

网页默认地址：<http://localhost:8501>

## 运行命令行 Demo

激活虚拟环境后运行：

```powershell
python run_demo.py
```

所有生成结果保存在 `outputs` 文件夹中。

## 项目结构

```text
AI_PIC_Demo/
├─ core/                  # 参数解析、物理模型、优化、报告与打包
├─ layout/                # GDS 和版图预览生成
├─ outputs/               # 已生成的展示结果
├─ app.py                 # Streamlit 网页入口
├─ run_demo.py            # 命令行入口
├─ requirements.txt       # Python 依赖
└─ start_demo.bat         # Windows 一键启动
```
