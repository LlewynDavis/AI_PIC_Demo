import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from core.mmi_model import estimate_mmi_length, toy_mmi_response


def optimize_length(spec, output_dir: Path):
    """
    对 MMI 长度进行参数扫描，并寻找最优长度。

    这一部分对应平台中的“参数扫描与优化模块”。
    """
    wavelength_um = spec["wavelength_um"]
    neff = spec["neff"]
    mmi_width_um = spec["mmi_width_um"]

    initial_length_um = estimate_mmi_length(
        wavelength_um=wavelength_um,
        neff=neff,
        mmi_width_um=mmi_width_um,
    )

    length_min_um, length_max_um = spec["length_scan_range_um"]
    num_scan_points = spec["num_scan_points"]

    lengths_um = np.linspace(length_min_um, length_max_um, num_scan_points)

    p_out1, p_out2, insertion_loss_db, imbalance_db, score = toy_mmi_response(
        lengths_um=lengths_um,
        ideal_length_um=initial_length_um,
    )

    best_index = int(np.argmin(score))

    result = {
        "initial_length_um": float(initial_length_um),
        "best_length_um": float(lengths_um[best_index]),
        "p_out1": float(p_out1[best_index]),
        "p_out2": float(p_out2[best_index]),
        "insertion_loss_db": float(insertion_loss_db[best_index]),
        "imbalance_db": float(imbalance_db[best_index]),
    }

    result_path = output_dir / "optimization_result.json"
    with open(result_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=4, ensure_ascii=False)

    plot_length_sweep(
        lengths_um=lengths_um,
        p_out1=p_out1,
        p_out2=p_out2,
        best_length_um=result["best_length_um"],
        output_dir=output_dir,
    )

    return result


def plot_length_sweep(lengths_um, p_out1, p_out2, best_length_um, output_dir: Path):
    """
    绘制 MMI 长度扫描结果图。
    """
    plt.figure(figsize=(8, 5))
    plt.plot(lengths_um, p_out1, label="Output port 1")
    plt.plot(lengths_um, p_out2, label="Output port 2")
    plt.axvline(best_length_um, linestyle="--", label="Best length")

    plt.xlabel("MMI length (um)")
    plt.ylabel("Normalized output power")
    plt.title("1x2 MMI Length Sweep")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()

    plot_path = output_dir / "length_sweep.png"
    plt.savefig(plot_path, dpi=300)
    plt.close()

    return plot_path
