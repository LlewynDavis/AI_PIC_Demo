"""Command-line entry point for the complete MMI design demo."""

from pathlib import Path

from core.optimizer import optimize_length
from core.package_generator import create_result_package
from core.report_generator import generate_report
from core.spec_parser import create_design_spec
from layout.gds_generator import generate_gds, generate_layout_preview


PROJECT_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = PROJECT_DIR / "outputs"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def main() -> None:
    """Run the complete V0 workflow using the shared project modules."""
    spec = create_design_spec(output_dir=OUTPUT_DIR)
    result = optimize_length(spec=spec, output_dir=OUTPUT_DIR)
    gds_path = generate_gds(spec=spec, result=result, output_dir=OUTPUT_DIR)
    layout_preview_path = generate_layout_preview(
        spec=spec,
        result=result,
        output_dir=OUTPUT_DIR,
    )
    report_path = generate_report(
        spec=spec,
        result=result,
        gds_path=gds_path,
        output_dir=OUTPUT_DIR,
    )
    package_path = create_result_package(output_dir=OUTPUT_DIR)

    print("=" * 60)
    print("AI-Assisted 1x2 MMI Splitter Design Demo Finished")
    print("=" * 60)
    print(f"Initial MMI length: {result['initial_length_um']:.3f} um")
    print(f"Best MMI length:    {result['best_length_um']:.3f} um")
    print(f"Output port 1:      {result['p_out1']:.4f}")
    print(f"Output port 2:      {result['p_out2']:.4f}")
    print(f"Insertion loss:     {result['insertion_loss_db']:.3f} dB")
    print(f"Imbalance:          {result['imbalance_db']:.3f} dB")
    print("-" * 60)
    print(f"GDS file:           {gds_path}")
    print(f"Layout preview:     {layout_preview_path}")
    print(f"Report:             {report_path}")
    print(f"Plot:               {OUTPUT_DIR / 'length_sweep.png'}")
    print(f"Result package:      {package_path}")
    print("=" * 60)


if __name__ == "__main__":
    main()
