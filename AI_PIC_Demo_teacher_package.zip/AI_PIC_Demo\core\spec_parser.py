import json
import re
from pathlib import Path


def save_design_spec(spec: dict, output_dir: Path):
    """
    保存设计参数到 design_spec.json。

    这个函数既可以给 run_demo.py 使用，
    也可以给 Streamlit 网页界面使用。
    """
    spec_path = output_dir / "design_spec.json"

    with open(spec_path, "w", encoding="utf-8") as f:
        json.dump(spec, f, indent=4, ensure_ascii=False)

    return spec_path


def create_design_spec(output_dir: Path):
    """
    创建设计参数。

    当前 V0 版本中，设计参数是手动写死的。
    后续可以将这一部分替换为 AI 需求解析模块，
    让 AI 根据自然语言生成结构化设计参数。
    """
    spec = {
        "component": "1x2_mmi_splitter",
        "platform": "SOI",
        "wavelength_um": 1.55,
        "neff": 2.8,
        "waveguide_width_um": 0.5,
        "mmi_width_um": 2.5,
        "target_split_ratio": [0.5, 0.5],
        "length_scan_range_um": [3.0, 20.0],
        "num_scan_points": 200,
    }

    save_design_spec(spec=spec, output_dir=output_dir)

    return spec


def parse_design_text(user_text: str):
    """
    规则版自然语言需求解析器。

    作用：
    从用户输入的自然语言中提取光子器件设计参数。

    当前版本不是大模型 AI，
    而是用规则和关键词完成一个可控的 demo。
    后续可以替换为 ChatGPT / OpenAI API / LangGraph。
    """
    text = user_text.lower()

    parsed = {
        "component": "1x2_mmi_splitter",
        "platform": "SOI",
        "wavelength_um": 1.55,
        "neff": 2.8,
        "waveguide_width_um": 0.5,
        "mmi_width_um": 2.5,
        "target_split_ratio": [0.5, 0.5],
        "length_scan_range_um": [3.0, 20.0],
        "num_scan_points": 200,
    }

    # 解析器件类型
    if "mmi" in text or "分束器" in text or "splitter" in text:
        parsed["component"] = "1x2_mmi_splitter"

    # 解析平台
    if "soi" in text:
        parsed["platform"] = "SOI"

    # 解析波长，例如 1550 nm
    nm_match = re.search(r"(\d+\.?\d*)\s*nm", text)
    if nm_match:
        wavelength_nm = float(nm_match.group(1))
        parsed["wavelength_um"] = wavelength_nm / 1000

    # 解析波长，例如 1.55 um 或 1.55 μm
    um_match = re.search(r"(\d+\.?\d*)\s*(um|μm)", text)
    if um_match:
        parsed["wavelength_um"] = float(um_match.group(1))

    # 解析 50:50 分光
    if "50:50" in text or "50/50" in text or "等分" in text or "均分" in text:
        parsed["target_split_ratio"] = [0.5, 0.5]

    # 解析有效折射率，例如 neff 2.8
    neff_match = re.search(r"neff\s*=?\s*(\d+\.?\d*)", text)
    if neff_match:
        parsed["neff"] = float(neff_match.group(1))

    # 解析波导宽度，例如 waveguide width 0.5 um
    wg_match = re.search(r"waveguide\s*width\s*=?\s*(\d+\.?\d*)", text)
    if wg_match:
        parsed["waveguide_width_um"] = float(wg_match.group(1))

    # 解析 MMI 宽度，例如 mmi width 2.5 um
    mmi_width_match = re.search(r"mmi\s*width\s*=?\s*(\d+\.?\d*)", text)
    if mmi_width_match:
        parsed["mmi_width_um"] = float(mmi_width_match.group(1))

    return parsed