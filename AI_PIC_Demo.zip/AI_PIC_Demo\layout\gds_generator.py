from pathlib import Path

import gdsfactory as gf
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle


def generate_gds(spec, result, output_dir: Path):
    """
    使用 gdsfactory 生成 1x2 MMI 的 GDS 版图。

    这一部分对应传统 PIC 设计流程中的“版图生成”。
    """
    # gdsfactory 9.x requires an active PDK in every new Python process.
    gf.gpdk.PDK.activate()

    length_mmi = result["best_length_um"]
    width_mmi = spec["mmi_width_um"]
    waveguide_width = spec["waveguide_width_um"]

    component = gf.components.mmi1x2(
        width=waveguide_width,
        width_mmi=width_mmi,
        length_mmi=length_mmi,
    )

    gds_path = output_dir / "mmi1x2_demo.gds"
    component.write_gds(gds_path)

    return gds_path


def generate_layout_preview(spec, result, output_dir: Path):
    """
    生成 1x2 MMI 的简化版图预览图。

    注意：
    这个图不是 GDS 文件本身的精确截图，
    而是根据当前设计参数绘制的结构示意预览图，
    用于在网页中直观展示器件的大致版图结构。
    """
    length_mmi = result["best_length_um"]
    width_mmi = spec["mmi_width_um"]
    waveguide_width = spec["waveguide_width_um"]

    input_wg_length = 3.0
    output_wg_length = 4.0
    output_gap = width_mmi / 2

    fig, ax = plt.subplots(figsize=(9, 4))

    # 输入波导
    input_wg = Rectangle(
        (-input_wg_length, -waveguide_width / 2),
        input_wg_length,
        waveguide_width,
        fill=False,
        linewidth=2,
    )
    ax.add_patch(input_wg)

    # MMI 多模干涉区域
    mmi_region = Rectangle(
        (0, -width_mmi / 2),
        length_mmi,
        width_mmi,
        fill=False,
        linewidth=2,
    )
    ax.add_patch(mmi_region)

    # 上输出波导
    upper_output = Rectangle(
        (length_mmi, output_gap / 2 - waveguide_width / 2),
        output_wg_length,
        waveguide_width,
        fill=False,
        linewidth=2,
    )
    ax.add_patch(upper_output)

    # 下输出波导
    lower_output = Rectangle(
        (length_mmi, -output_gap / 2 - waveguide_width / 2),
        output_wg_length,
        waveguide_width,
        fill=False,
        linewidth=2,
    )
    ax.add_patch(lower_output)

    # 添加文字标注
    ax.text(
        length_mmi / 2,
        0,
        "MMI region",
        ha="center",
        va="center",
        fontsize=11,
    )
    ax.text(
        -input_wg_length / 2,
        waveguide_width,
        "Input",
        ha="center",
        fontsize=10,
    )
    ax.text(
        length_mmi + output_wg_length / 2,
        output_gap / 2 + waveguide_width,
        "Output 1",
        ha="center",
        fontsize=10,
    )
    ax.text(
        length_mmi + output_wg_length / 2,
        -output_gap / 2 - waveguide_width * 2,
        "Output 2",
        ha="center",
        fontsize=10,
    )

    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("x / μm")
    ax.set_ylabel("y / μm")
    ax.set_title("Simplified Layout Preview of 1x2 MMI Splitter")
    ax.grid(True)

    margin = 1.5
    ax.set_xlim(-input_wg_length - margin, length_mmi + output_wg_length + margin)
    ax.set_ylim(-width_mmi / 2 - margin, width_mmi / 2 + margin)

    plt.tight_layout()

    preview_path = output_dir / "layout_preview.png"
    plt.savefig(preview_path, dpi=300)
    plt.close()

    return preview_path
